/* Onetime DimTime dimension load this will take time depending on the oldest date in the history records*/

DECLARE @CurrentDate DATE = (select cast(Min([Year]) as char(4)) + '-01-01' from dbo.FactWeatherMonth)
DECLARE @EndDate DATE = CAST(getdate()-1 as Date)

WHILE @CurrentDate < @EndDate
BEGIN
   INSERT INTO [dbo].[DimTime] (
DateKey,
[Date],
[Year],
[Month],
[From],
[To]
)
   SELECT DateKey = YEAR(@CurrentDate) * 10000 + MONTH(@CurrentDate) * 100 + DAY(@CurrentDate),
      DATE = @CurrentDate,
      [Year] = YEAR(@CurrentDate),
	  [Month] = MONTH(@CurrentDate),
      [From] = Null,
	  [To] = Null

   SET @CurrentDate = DATEADD(DD, 1, @CurrentDate)
END
/*This procedure needs to created once, this will be called in ETL during every refresh 
This will refresh the 3 fact tables */
Use WeatherDWH
Go

CREATE PROCEDURE dbo.Refresh_Facts
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
/* Fact3Hours refresh */
select distinct dt.DateTimeKey,
dl.LocationKey,
st.[min] as Temp_min,
st.[max] as Temp_max,
st.[value] as Rainfall 
into #stage
from [dbo].[staging] st 
join dbo.DateStaging ds on st.time_Id=ds.time_Id
join dbo.DimTime dt on dt.[From]=ds.[From] and dt.[to]=ds.[To] 
join dbo.Dimlocation dl on dl.City=st.city

Update  f
set Temp_min= s.Temp_min,
Temp_max=s.Temp_max,
Rainfall =s.Rainfall,
Updated = getdate()
from #stage s
left join dbo.FactWeather3Hours f on f.DateTimeKey=s.DateTimeKey
and s.LocationKey=f.LocationKey
where f.DateTimeKey is not null

insert into dbo.FactWeather3Hours
(
DateTimeKey
,LocationKey
,Temp_min
,Temp_max
,Rainfall
,Inserted
,Updated
)
select s.DateTimeKey,
s.LocationKey,
s.Temp_min,
s.Temp_max,
s.Rainfall,
getdate(),
getdate()
from #stage s
left join dbo.FactWeather3Hours f on f.DateTimeKey=s.DateTimeKey
and s.LocationKey=f.LocationKey
where f.DateTimeKey is null




/* Fact Day */

select DateKey as DateKey,
LocationKey,
min(Temp_min) as Temp_min,
max(Temp_max) as Temp_max,
sum(isnull(Rainfall,0)) as Rainfall into #stageday
from dbo.FactWeather3Hours F 
join dbo.DimTime D on D.DateTimeKey = F.DateTimeKey
group by DateKey,LocationKey

Update  f
set Temp_min= s.Temp_min,
Temp_max=s.Temp_max,
Rainfall =s.Rainfall,
Updated = getdate()
from #stageday s
left join dbo.FactWeatherDay f on f.DateKey=s.DateKey
and s.LocationKey=f.LocationKey
where f.DateKey is not null


insert into dbo.FactWeatherDay
(
DateKey
,LocationKey
,Temp_min
,Temp_max
,Rainfall
,Inserted
,Updated
)

select s.DateKey,
s.LocationKey,
s.Temp_min,
s.Temp_max,
s.Rainfall,
getdate(),
getdate()
from #stageday s
left join dbo.FactWeatherDay f on f.DateKey=s.DateKey
and s.LocationKey=f.LocationKey
where f.DateKey is null



/* Fact Monthly */

select L.City as City,
D.[Year] as [Year],
D.[Month] as [Month],
min(Temp_min) as Temp_min,
max(Temp_max) as Temp_max,
sum(isnull(Rainfall,0)) as Rainfall into #stageMonth
from dbo.FactWeatherDay F
join dbo.DimTime D on F.DateKey =D.DateKey 
join dbo.DimLocation L on F.LocationKey =L.LocationKey
group by D.[Year],D.[Month],L.City

Update  f
set Temp_min= s.Temp_min,
Temp_max=s.Temp_max,
Rain_mm =s.Rainfall,
Updated = getdate()
from #stageMonth s
left join dbo.FactWeatherMonth f on f.[Year]=s.[Year] and f.[Month]=s.[Month] and s.city=f.city
where f.[Year] is not null

insert into dbo.FactWeatherMonth
(
City
,[Year]
,[Month]
,Temp_Min
,Temp_Max
,Rain_mm
,Inserted
,Updated
)

select s.city,
s.[Year],
s.[Month],
s.Temp_min,
s.Temp_max,
s.Rainfall,
getdate(),
getdate() 
from #stageMonth s
left join dbo.FactWeatherMonth f on f.[Year]=s.[Year] and f.[Month]=s.[Month] and s.city=f.city
where f.[Year] is null


END
GO

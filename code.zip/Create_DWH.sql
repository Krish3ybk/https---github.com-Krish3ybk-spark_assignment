USE [master]
GO

create database [WeatherDWH]
go

USE [WeatherDWH]
GO
/****** Object:  Table [dbo].[DateStaging]    Script Date: 10/9/2019 9:52:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DateStaging](
	[time_Id] [numeric](20, 0) NULL,
	[Date] [date] NULL,
	[from] [datetime] NULL,
	[to] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dimlocation]    Script Date: 10/9/2019 9:52:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dimlocation](
	[LocationKey] [int] IDENTITY(1,1) NOT NULL,
	[City] [varchar](20) NULL,
	[County_code] [varchar](2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DimTime]    Script Date: 10/9/2019 9:52:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DimTime](
	[DateTimeKey] [int] IDENTITY(1,1) NOT NULL,
	[DateKey] [int] NULL,
	[Date] [date] NULL,
	[Year] [int] NULL,
	[Month] [int] NULL,
	[From] [datetime] NULL,
	[To] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FactWeather3Hours]    Script Date: 10/9/2019 9:52:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FactWeather3Hours](
	[DateTimeKey] [int] NULL,
	[LocationKey] [int] NULL,
	[Temp_min] [decimal](10, 2) NULL,
	[Temp_max] [decimal](10, 2) NULL,
	[Rainfall] [decimal](10, 2) NULL,
	[Inserted] [datetime] default getdate(),
	[Updated] [datetime] default getdate()
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FactWeatherDay]    Script Date: 10/9/2019 9:52:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FactWeatherDay](
	[DateKey] [int] NULL,
	[LocationKey] [int] NULL,
	[Temp_min] [decimal](10, 2) NULL,
	[Temp_max] [decimal](10, 2) NULL,
	[Rainfall] [decimal](10, 2) NULL,
	[Inserted] [datetime] default getdate(),
	[Updated] [datetime] default getdate()
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FactWeatherMonth]    Script Date: 10/9/2019 9:52:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FactWeatherMonth](
	[City] [varchar](255) NULL,
	[Year] [varchar](255) NULL,
	[Month] [varchar](255) NULL,
	[Temp_Max] [varchar](255) NULL,
	[Temp_Min] [varchar](255) NULL,
	[Rain_mm] [varchar](255) NULL,
	[Inserted] [datetime] default getdate(),
	[Updated] [datetime] default getdate()
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Staging]    Script Date: 10/9/2019 9:52:40 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Staging](
	[city] [varchar](50) NULL,
	[time_Id] [numeric](20, 0) NULL,
	[min] [decimal](28, 10) NULL,
	[max] [decimal](28, 10) NULL,
	[value] [decimal](28, 10) NULL
) ON [PRIMARY]
GO

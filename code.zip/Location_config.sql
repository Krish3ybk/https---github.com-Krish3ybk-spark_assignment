/* Dimlocation & new locations config table */


insert into dbo.Dimlocation
values 
('armagh','ca'),
('aberporth','gb'),
('braemar','au'),
('bradford','gb'),
('ballypatrick','ie')
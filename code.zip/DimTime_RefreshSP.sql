/*This procedure needs to created once, this will be called in ETL during every refresh 
This will new datetime entries in DimTime*/

Use WeatherDWH
Go

CREATE PROCEDURE dbo.Refresh_DimTime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   /*DimTime update*/
Insert into  dbo.DimTime
select distinct Replace(cast(SD.[Date] as VARCHAR(10)),'-','') as DateKey,
SD.[Date] as [Date],
Year(SD.[Date]) as [Year],
Month(SD.[Date]) as [Month],
SD.[From],SD.[To] from [dbo].[DateStaging] SD
Left join DimTime DT on DT.[From]=SD.[From] and DT.[To]=SD.[To]
where DT.DateTimeKey is null

END
GO
